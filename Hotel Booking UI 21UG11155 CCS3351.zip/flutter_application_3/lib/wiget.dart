import 'package:flutter/material.dart';

class HotelWidget extends StatelessWidget {
  final String hotelName;
  final String price;
  final String location;
  final String distance;
  final String reviews;
  final String imagePath;

  HotelWidget({
    required this.hotelName,
    required this.price,
    required this.location,
    required this.distance,
    required this.reviews,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    //row1
    final name = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          hotelName,
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w800,
            fontSize: 20,
          ),
        ),
        Text(
          price,
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w800,
            fontSize: 20,
          ),
        ),
      ],
    );

    //row2
    final locationWidget = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(location),
        Text(distance),
        Text("per night"),
      ],
    );

    final stars = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.star, color: Colors.green[500]),
        Icon(Icons.star, color: Colors.green[500]),
        Icon(Icons.star, color: Colors.green[500]),
        const Icon(Icons.star_border_outlined, color: Colors.green),
        const Icon(Icons.star_border_outlined, color: Colors.green),
      ],
    );

    final ratings = Container(
      padding: const EdgeInsets.all(20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          stars,
          Text(reviews),
        ],
      ),
    );

    // Image widget
    final hotelImage = Image.asset(
      'imges/$imagePath',
      width: 800,
      height: 200,
      fit: BoxFit.cover,
    );

    return Container(
      decoration: BoxDecoration(
        color: Colors.white70,
        borderRadius: BorderRadius.circular(20.0),
      ),
      margin: EdgeInsets.all(10.0),
      padding: EdgeInsets.all(10.0),
      child: Column(
        children: [
          hotelImage,
          name,
          SizedBox(height: 15),
          locationWidget,
          ratings,
        ],
      ),
    );
  }
}