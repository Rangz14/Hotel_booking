import 'package:flutter/material.dart';

void main() {
  runApp(MainApp());
}

class HotelWidget extends StatelessWidget {
  final String hotelName;
  final String price;
  final String location;
  final String distance;
  final String reviews;
  final String imagePath;

  HotelWidget({
    required this.hotelName,
    required this.price,
    required this.location,
    required this.distance,
    required this.reviews,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    final name = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          hotelName,
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w800,
            fontSize: 20,
          ),
        ),
        Text(
          price,
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w800,
            fontSize: 20,
          ),
        ),
      ],
    );

    final locationWidget = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(location),
        Text(distance),
        Text("per night"),
      ],
    );

    final stars = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.star, color: Colors.green[500]),
        Icon(Icons.star, color: Colors.green[500]),
        Icon(Icons.star, color: Colors.green[500]),
        const Icon(Icons.star_border_outlined, color: Colors.green),
        const Icon(Icons.star_border_outlined, color: Colors.green),
      ],
    );

    final ratings = Container(
      padding: const EdgeInsets.all(20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          stars,
          Text(reviews),
        ],
      ),
    );

    final hotelImage = Image.asset(
      'imges/$imagePath',
      width: 800,
      height: 200,
      fit: BoxFit.cover,
    );

    return Card(
      elevation: 5.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      margin: EdgeInsets.all(10.0),
      child: Column(
        children: [
          hotelImage,
          name,
          SizedBox(height: 15),
          locationWidget,
          ratings,
        ],
      ),
    );
  }
}

class HotelAppTitle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              // Implement your back arrow functionality here
            },
          ),
        ),
        Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Explore',
                  style: TextStyle(
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
              SizedBox(height: 8.0),
              Container(
                height: 2.0,
                width: double.infinity,
                color: Colors.black,
              ),
              SizedBox(height: 8.0),
            ],
          ),
        ),
        Align(
          alignment: Alignment.centerRight,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(
                icon: Icon(Icons.favorite, color: Colors.black),
                onPressed: () {
                  // Implement your favorite/heart icon functionality here
                },
              ),
              IconButton(
                icon: Icon(Icons.location_on, color: Colors.black),
                onPressed: () {
                  // Implement your location icon functionality here
                },
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class MainApp extends StatelessWidget {
  MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              HotelAppTitle(),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.search,
                          color: Colors.green,
                        ),
                      ),
                      Expanded(
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: 'Search Hotels...',
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: ListView(
                  children: [
                    HotelWidget(
                      hotelName: "Queens Hotel",
                      price: "USD250.00",
                      location: "Kandy",
                      distance: "2km to city",
                      reviews: "180 Reviews",
                      imagePath: 'queens.jpg',
                    ),
                    SizedBox(height: 10),
                    HotelWidget(
                      hotelName: "Taj Samudra",
                      price: "USD200.00",
                      location: "Colombo",
                      distance: "1km to city",
                      reviews: "120 Reviews",
                      imagePath: 'tajj.jpg',
                    ),
                    SizedBox(height: 10),
                    HotelWidget(
                      hotelName: "Galadari",
                      price: "USD300.00",
                      location: "Colombo",
                      distance: "2km to city",
                      reviews: "200 Reviews",
                      imagePath: 'galadari.jpg',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}